package com.example.user.mad_project_final;

public class DataModel {

    public String Date;
    public String remark;
    public String Spend;
   // public String Practicals;

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {

        this.Date=Date;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getSpend() {
        return Spend;
    }

    public void setSpend(String Spend) {
        this.Spend = Spend;
    }

}

